import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-medicine-home',
  templateUrl: './medicine-home.component.html',
  styleUrls: ['./medicine-home.component.scss']
})
export class MedicineHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
